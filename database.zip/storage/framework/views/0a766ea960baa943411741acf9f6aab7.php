<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme">
  <head>
    <!-- Required meta tags -->
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<!-- Favicon icon-->
<link
  rel="shortcut icon"
  type="image/png"
  href="../assets/images/logos/favicon.png"
/>

<!-- Core Css -->
<link rel="stylesheet" href="../assets/css/styles.css" />

<title><?php echo e(config('app.name', 'Skale.AI')); ?></title>
    <!-- Owl Carousel  -->
    <link
      rel="stylesheet"
      href="../assets/libs/owl.carousel/dist/assets/owl.carousel.min.css"
    />
  </head>

  <body>
    <!-- Preloader -->
    <div class="preloader">
      <img
        src="../assets/images/logos/favicon.png"
        alt="loader"
        class="lds-ripple img-fluid"
      />
    </div>
    <div id="main-wrapper">
      <!-- Sidebar Start -->
     
          <!-- ---------------------------------- -->
<!-- Start Vertical Layout Sidebar -->
<!-- ---------------------------------- -->


<?php echo $__env->make('modules.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ---------------------------------- -->
<!-- Start Vertical Layout Sidebar -->
<!-- ---------------------------------- -->

      <!--  Sidebar End -->
      <div class="page-wrapper">
        <!--  Header Start -->
    
        <?php echo $__env->make('modules.mainheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('modules.leftsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
            <main>
                <?php echo e($slot); ?>

            </main>
            <?php echo $__env->make('modules.settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
        </div>
  
        <!--  Search Bar -->
        <?php echo $__env->make('modules.searchBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  
        <!--  Shopping Cart -->
        <?php echo $__env->make('modules.shoppingCart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  
      </div>
      <?php echo $__env->make('modules.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\scale.ai\resources\views/layouts/app.blade.php ENDPATH**/ ?>