<div class="dark-transparent sidebartoggler"></div>
<!-- Import Js Files -->

<script src="../assets/libs/jquery/dist/jquery.min.js"></script>
<script src="../assets/js/app.min.js"></script>
<script src="../assets/js/app.init.js"></script>
<script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/libs/simplebar/dist/simplebar.min.js"></script>

<script src="../assets/js/sidebarmenu.js"></script>
<script src="../assets/js/theme.js"></script>

<script src="../assets/libs/owl.carousel/dist/owl.carousel.min.js"></script>
<script src="../assets/libs/apexcharts/dist/apexcharts.min.js"></script>
<script src="../assets/js/dashboards/dashboard.js"></script>


</body>
</html>
